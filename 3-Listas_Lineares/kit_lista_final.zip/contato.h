#ifndef CONTATO_H
#define CONTATO_H

typedef struct contato {
    char nome[140];
    char telefone[20];
    int ano, mes, dia;
} contato;

#endif // CONTATO_H
